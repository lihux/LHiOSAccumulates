/* File: Grades.c
 * Uses functions in libRatings.B.dylib.
 **************************************/

#include <stdio.h>
#include <string.h>
#include <dlfcn.h>
#include "RatingsAsGrades.h"

#define MAX_NAMES 100
#define MAX_NAME_LENGTH 30
#define MAX_RATING_LENGTH 5

static char *name_list[MAX_NAMES];
static char *rating_list[MAX_NAMES];
static int names = 0;

void addNameAndRating(char* name, char* rating) {
    name_list[names] = strdup(name);
    rating_list[names] = (strlen(rating) > MAX_RATING_LENGTH)? "*****" : strdup(rating);
    names++;
}

void test_data(void) {

    addNameAndRating("Eloise", "F");
    addNameAndRating("Karla", "B");
    addNameAndRating("Iva", "B");
    addNameAndRating("Hilaire", "F");
    addNameAndRating("Jewel", "B");
    addNameAndRating("Simone", "A");
    addNameAndRating("Yvette", "A");
    addNameAndRating("Renee", "A");
    addNameAndRating("Mimi", "A");
}

int main(int argc, char *argv[]) {
    int test_mode = 0;
    if (argc == 2) {
        if (strcmp(argv[1], "test") == 0) {
            test_mode = 1;
            printf("[start_test]\n");
            test_data();
        }
    }
    else {
        printf("Enter student names and grades in the form <name> <rating>.\n");
        printf("No spaces are allowed in the name and the rating.\n");
        printf("The grade can be A through F.\n");
        printf("To finish, enter \"end\" for a student name.\n");
        while (names < MAX_NAMES) {
            char name[MAX_NAME_LENGTH];
            char rating[MAX_RATING_LENGTH];
            printf("\nName and rating: ");
            scanf("%s", &name);
            if (strcmp(name, "end") == 0) {
                break;
            }
            scanf("%s", rating);
            addNameAndRating(name, rating);
        }
        printf("\n");
    }
    
    if (names) {
        // Print data entered and call libRatings.addRating().
        printf("This is the data you entered:\n");
        int i;
        for (i = 0; i < names; i++) {
            printf("%s\t(%s)\n", name_list[i], rating_list[i]);
            addRating(rating_list[i]);
        }
        
        // Print statistical information.
        printf("\nThe median grade is %s\n", medianRating());
        printf("The most frequent grade is %s\n", frequentRating());
        
    }
    
    if (test_mode) {
        printf("[end_test]\n");
    }
    return 0;
}


/* StarMeals.c Version History
 * 1. First version.
 */