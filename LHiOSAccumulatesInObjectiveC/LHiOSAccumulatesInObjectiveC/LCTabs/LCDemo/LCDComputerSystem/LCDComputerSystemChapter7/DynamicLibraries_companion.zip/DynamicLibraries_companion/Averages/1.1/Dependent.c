/* Dependent.c (2)                                  */
/* Tests SimpleStats.A.dylib as a dependent library */

#include <stdio.h>
#include <stdlib.h>
#include "Averages.h"

int main(int argc, char** argv) {
    printf("\n[start_test]\n");

    // Setup.
    add(5);
    add(4);
    add(3);
    add(2);
    add(1);

    // count() test.
    printf("[%s] count(): %s\n", __FILE__, (count() == 5? "Passed":"Failed"));
    
    // mean() test.
    printf("[%s] mean(): %s\n", __FILE__, (mean() == 3? "Passed":"Failed"));
    
    // Odd set, median() test (libAverages.A.dylib 1.1).
    if (median) {
        printf("[%s] (odd set) median(): %s\n", __FILE__, (median() == 3? "Passed":"Failed"));
    }
    else {
        printf("[%s] (odd set) median(): %s\n", __FILE__, "Untested");
    }
    
    // clear() test.
    clear();
    printf("[%s] clear(): %s\n", __FILE__, (count() == 0? "Passed":"Failed"));
    
    // Even set, median() test (libAverages.A.dylib 1.1).
    add(4);
    add(3);
    add(2);
    add(1);
    if (median) {
        printf("[%s] (even set) median(): %s\n", __FILE__, (median() == 2? "Passed":"Failed"));
    }
    else {
        printf("[%s] (even set) median(): %s\n", __FILE__, "Untested");
    }

    // mode() text (libAverages.A.dylib 1.1).
    clear();
    add(1);
    add(3);
    add(4);
    add(2);
    add(3);
    add(2);
    add(3);
    if (mode) {
        printf("[%s] mode(): %s\n", __FILE__, (mode() == 3? "Passed":"Failed"));
    }
    else {
        printf("[%s] mode(): %s\n", __FILE__, "Untested");
    }
    
    printf("[end_test]\n\n");
    return EXIT_SUCCESS;
}


/* File revision history
    2 Added test for median() and mode().
    1 First version of this file.
*/
