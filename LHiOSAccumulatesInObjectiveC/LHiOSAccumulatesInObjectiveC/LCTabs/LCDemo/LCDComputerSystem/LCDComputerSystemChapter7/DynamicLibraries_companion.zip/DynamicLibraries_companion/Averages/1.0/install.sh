#!/bin/sh
# $1 Dynamic library name.
# $2 Major version.
# Example:
#	./install.sh Averages A

if test $1 && test $2; then
    mkdir -p ~/include
    mkdir -p ~/lib
	cp -f $1.h ~/include
	./install_lib.sh $1 $2
fi
