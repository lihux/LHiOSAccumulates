/* Dependent.c (1)                               */
/* Tests Averages.A.dylib as a dependent library */

#include <stdio.h>
#include "Averages.h"

int main(int argc, char** argv) {
    printf("\n[start_test]\n");

    // Setup.
    add(5);
    add(4);
    add(3);
    add(2);
    add(1);

    // count() test.
    printf("[%s] Test count(): %s\n", __FILE__, (count() == 5? "Passed":"Failed"));
    
    // mean() test.
    printf("[%s] Test mean(): %s\n", __FILE__, (mean() == 3? "Passed":"Failed"));

    // clear() test.
    clear();
    printf("[%s] Test clear(): %s\n", __FILE__, (count() == 0? "Passed":"Failed"));

    printf("[end_test]\n\n");
    return 0;
}


/* File revision history
    1 First version of this file.
*/
