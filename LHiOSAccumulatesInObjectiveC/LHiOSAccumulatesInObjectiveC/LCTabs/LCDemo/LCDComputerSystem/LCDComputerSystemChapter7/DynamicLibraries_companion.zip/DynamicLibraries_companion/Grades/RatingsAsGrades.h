/* File: RatingsInterposed.h
 * Interface to the RatingsAsGrages dynamic library.
 **************************************************/

/* Adds 'grade' to the set.
 *      grade: Non-NULL string. Contains zero or one of these characters:
 *             A, B, C, D, F.
 *             Examples: "", "A", "B".
 */
void addRating(char* grade);

/* Returns the median grade.
 */
char *medianRating(void);

/* Returns the most frequent grade.
 */
char *frequentRating(void);
