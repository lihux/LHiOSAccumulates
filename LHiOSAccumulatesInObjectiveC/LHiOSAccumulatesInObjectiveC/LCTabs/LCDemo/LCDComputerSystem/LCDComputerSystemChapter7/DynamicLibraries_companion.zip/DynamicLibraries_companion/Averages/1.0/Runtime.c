/* Runtime.c (1)                                         */
/* Tests libAverages.A.dylib as a runtime loaded library */

#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>
#include "Averages.h"

int main(int argc, char **argv) {
    printf("\n[start_test]\n");

    // Open the library.
    char *lib_name = "./libAverages.A.dylib";
    void *lib_handle = dlopen(lib_name, RTLD_NOW);
    if (lib_handle) {
        printf("[%s] dlopen(\"%s\", RTLD_NOW): Successful\n", __FILE__, lib_name);
    }
    else {
        printf("[%s] Unable to open library: %s\n",
            __FILE__, dlerror());
        exit(EXIT_FAILURE);
    }
    
    // Get the symbol addresses.
    void (*add)(int) = dlsym(lib_handle, "add");
    if (add) {
        printf("[%s] dlsym(lib_handle, \"add\"): Successful\n", __FILE__);
    }
    else {
        printf("[%s] Unable to get symbol: %s\n",
            __FILE__, dlerror());
        exit(EXIT_FAILURE);
    }
    int (*mean)(void) = dlsym(lib_handle, "mean");
    if (mean) {
        printf("[%s] dlsym(lib_handle, \"mean\"): Successful\n", __FILE__);
    }
    else {
        printf("[%s] Unable to get symbol: %s\n",
            __FILE__, dlerror());
        exit(EXIT_FAILURE);
    }
    void (*clear)(void) = dlsym(lib_handle, "clear");
    if (clear) {
        printf("[%s] dlsym(lib_handle, \"clear\"): Successful\n", __FILE__);
    }
    else {
        printf("[%s] Unable to get symbol: %s\n",
            __FILE__, dlerror());
        exit(EXIT_FAILURE);
    }
    int (*count)(void) = dlsym(lib_handle, "count");
    if (count) {
        printf("[%s] dlsym(lib_handle, \"clear\"): Successful\n", __FILE__);
    }
    else {
        printf("[%s] Unable to get symbol: %s\n",
            __FILE__, dlerror());
        exit(EXIT_FAILURE);
    }
        
    // Setup.
    add(5);
    add(4);
    add(3);
    add(2);
    add(1);
    
    // count() text.
    printf("[%s] Test count(): %s\n", __FILE__, (count() == 5? "Passed":"Failed"));
    
    // mean() test.
    printf("[%s] Test mean(): %s\n", __FILE__, (mean() == 3? "Passed":"Failed"));
    
    // 
    // clear() test.
    clear();
    printf("[%s] Test clear(): %s\n", __FILE__, (count() == 0? "Passed":"Failed"));

    // Close the library.
    if (dlclose(lib_handle) == 0) {
        printf("[%s] dlclose(lib_handle): Successful\n", __FILE__);
    }
    else {
        printf("[%s] Unable to open close: %s\n",
            __FILE__, dlerror());
    }

    printf("[end_test]\n\n");
    return 0;
}

/* File revision history
    1 First version of this file.
*/
