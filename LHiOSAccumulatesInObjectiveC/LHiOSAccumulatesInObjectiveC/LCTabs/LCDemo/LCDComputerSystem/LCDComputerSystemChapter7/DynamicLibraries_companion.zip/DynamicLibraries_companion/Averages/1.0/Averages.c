/* File: Averages.c (1)                           */
/* Implementation of the Averages dynamic library */
/* Compile with -fvisibility=hidden               */

#include "Averages.h"
#include <stdio.h>
#include <string.h>
#define EXPORT __attribute__((visibility("default")))
#define MAX_NUMBERS 10

static int _number_list[MAX_NUMBERS];
static int _numbers = 0;

EXPORT
void add(int number) {
    if (_numbers < MAX_NUMBERS) {
        _number_list[_numbers++] = number;
    }
}

EXPORT
int mean(void) {
    int result = 0;
    if (_numbers) {
        int sum = 0;
        for (int i = 0; i < _numbers; i++) {
            sum += _number_list[i];
        }
        result = sum / _numbers;
    }
    return result;
}

EXPORT
int count(void) {
    return _numbers;
}

EXPORT
void clear(void) {
    _numbers = 0;
}


/* File revision history
    1 First version of this file.
*/
