/* Dependent.c
 * Tests libRatings.A.dylib 1.1 as a dependent library.
 *****************************************************/
 
#include <stdio.h>
#include <string.h>
#include "Ratings.h"

#define PASSFAIL "Passed":"Failed"
#define UNTST "Untested"

int main(int argc, char **argv) {
    printf("[start_test]\n");

    // Setup.
    addRating(NULL);
    addRating("");
    addRating("*");
    addRating("**");
    addRating("***");
    addRating("*****");
    addRating("*****");
    
    // ratings.
    printf("[%s] ratings(): %s\n",
        __FILE__, (ratings() == 6? PASSFAIL));
    
    // meanRating.
    printf("[%s] meanRating(): %s\n",
        __FILE__, (strcmp(meanRating(), "**") == 0)? PASSFAIL);

    // medianRating.
    if (medianRating) {                         // 1
        printf("[%s] medianRating(): %s\n",
            __FILE__, (strcmp(medianRating(), "**") == 0? PASSFAIL));
    }
    else {
        printf("[%s] medianRating(): %s\n", __FILE__, UNTST);
    }
    
    // frequentRating.
    if (frequentRating) {                         // 2
        char *test_rating = "*****";
        int test_rating_size = sizeof(test_rating);
        printf("[%s] frequentRating(): %s\n",
            __FILE__, strncmp(test_rating, frequentRating(),
            test_rating_size) == 0? PASSFAIL);
    }
    else {
        printf("[%s] mostFrequentRating(): %s\n",
            __FILE__, UNTST);
    }
    
    // clearRatings.
    clearRatings();
    printf("[%s] clearRatings(): %s\n",
        __FILE__, (ratings() == 0? PASSFAIL));

    printf("[end_test]\n");
    return 0;
}


/* Dependent.c revision history
 * 1. First version.
 * 2. Added tests for medianRating, frequentRating.
 */
