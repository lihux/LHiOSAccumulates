/* File: Avarages.h (1)                      */
/* Interface to the Avarages dynamic library */

// Adds 'number' to the set.
void add(int number);

// Returns the number of items in the set.
int count(void);

// Returns the mean of the set.
int mean(void);

// Clears the set.
void clear(void);


/* File revision history
    1 First version of this file.
*/
