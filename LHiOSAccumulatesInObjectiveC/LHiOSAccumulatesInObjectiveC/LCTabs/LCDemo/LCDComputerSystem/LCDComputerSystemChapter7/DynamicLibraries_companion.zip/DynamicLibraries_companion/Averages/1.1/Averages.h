/* File: Avarages.h (2)                      */
/* Interface to the Avarages dynamic library */

#define WEAK_IMPORT __attribute__((weak_import))

// Adds 'number' to the set.
void add(int number);

// The number of items in the set.
int count(void);

// The mean of the set.
int mean(void);

// The median of the set (added in Averages.h 2).
WEAK_IMPORT
int median(void);

// Mode of the set (added in Averages.h 2).
// Returns FLT_MIN (<float.h>) when the set is empty.
WEAK_IMPORT
int mode(void);

// Clears the set.
void clear(void);

// Prints the set (added in Averages.h 2).
WEAK_IMPORT
void print(void);


/* File revision history
    2 Added median() and print().
    1 First version of this file.
*/
