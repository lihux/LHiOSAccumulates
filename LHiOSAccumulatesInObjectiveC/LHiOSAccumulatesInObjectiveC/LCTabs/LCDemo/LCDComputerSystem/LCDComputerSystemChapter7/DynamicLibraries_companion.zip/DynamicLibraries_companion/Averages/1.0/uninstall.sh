#!/bin/sh
# $1 Dynamic library name.
# $2 Major version.
# Example:
#	./uninstall.sh Averages A

if test $1 && test $2; then
	rm -f ~/lib/lib$1.$2.dylib
	rm -f ~/lib/lib$1.dylib
	rm ~/include/$1.h
fi
