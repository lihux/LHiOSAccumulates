/* File: Averages.c
 * Compile with -fvisibility=hidden.
 **********************************/
 
#include "Averages.h"
#include <stdio.h>
#include <string.h>
#define EXPORT __attribute__((visibility("default")))
#define MAX_NUMBERS 10

static int _number_list[MAX_NUMBERS];
static int _numbers = 0;

// Used by _add, _sort_numbers.
static int _not_sorted = 0;

// Used by _sort_numbers.
void _swap_numbers(int number1_index, int number2_index) {
    int number_tmp = _number_list[number2_index];
    _number_list[number2_index] = _number_list[number1_index];
    _number_list[number1_index] = number_tmp;
}

// Used by _median, _mode.
void _sort_numbers() {
    if (_numbers > 1 && _not_sorted) {
        int i, j;
        for (int i = 0; i < _numbers; i++) {
            for (int j = 0; j < _numbers - (i+1); j++) {
                int k = j + 1;
                if (_number_list[j] > _number_list[k]) {
                    _swap_numbers(j, k);
                }
            }
        }
        _not_sorted = 0;
    }
}

EXPORT
void add(int number) {
    if (_numbers < MAX_NUMBERS) {
        _number_list[_numbers++] = number;
        _not_sorted = 1;
    }
}

EXPORT
int mean(void) {
    int result = 0;
    if (_numbers) {
        int sum = 0;
        int i;
        for (i = 0; i < _numbers; i++) {
            sum += _number_list[i];
        }
        result = sum / _numbers;
    }
    return result;
}

EXPORT
int median(void) {
    int result;
    _sort_numbers();
    int median_index = (int)(_numbers + 1) / 2 - 1;
    if (_numbers % 2 == 0) {
       int number1 = _number_list[median_index];
       int number2 = _number_list[median_index+1];
       result = (number1 + number2) / 2;
    }
    else {
        result = _number_list[median_index];
    }
    return result;
}

EXPORT
int mode(void) {
    int result = 0;
    int result_frequency = 0;
    _sort_numbers();
    int i = 0;
    while (i < _numbers) {
        int current_number = _number_list[i];
        int current_frequency = 1;
        i++;
        while (i < _numbers && _number_list[i] == current_number) {
            current_frequency++;
            i++;
        }
        if (current_frequency > 1 && current_frequency > result_frequency) {
            result = current_number;
            result_frequency = current_frequency;
        }
    }
    return result;
}

EXPORT
int count(void) {
    return _numbers;
}

EXPORT
void clear(void) {
    _numbers = 0;
}

/* File revision history
    2 Exported median() and mode().
    1 First version of this file.
*/
