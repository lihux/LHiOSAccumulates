#!/bin/sh
# $1 Dynamic library name.
# $2 Major version.
# Example:
#	./install_lib.sh Averages A

if test $1 && test $2; then
	cp -f lib$1.$2.dylib ~/lib
	ln -sf ~/lib/lib$1.$2.dylib ~/lib/lib$1.dylib
fi
