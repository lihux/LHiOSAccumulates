/* File: RatingsAsGrades.c
 * Compile with -fvisibility=hidden.
 ***********************************/

#include "RatingsAsGrades.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>

#define EXPORT __attribute__((visibility("default")))
#define MAX_STAR_RATING_LEN 6

static char *_ratingAsGrade(char* rating) {
    int rating_length = strlen(rating);
    if (rating_length > MAX_STAR_RATING_LEN - 1) {
        rating_length = MAX_STAR_RATING_LEN - 1;
    }
    char grade;
    switch (rating_length) {
        case 5:
            grade = 'A';
            break;
        case 4:
            grade = 'B';
            break;
        case 3:
            grade = 'C';
            break;
        case 2:
            grade = 'D';
            break;
        case 1:
            grade = 'F';
            break;
        default:
            grade = '\0';
    }
    char char_grade[2] = { grade, '\0' };
    return strdup(char_grade);
}

// Interpose libRatings.B.dylib:addRating.
EXPORT
void addRating(char* grade) {
    char rating[MAX_STAR_RATING_LEN] = { '\0' };
    switch (*grade) {
        case 'A':
            strcat(rating, "*");
        case 'B':
            strcat(rating, "*");
        case 'C':
            strcat(rating, "*");
        case 'D':
            strcat(rating, "*");
        case 'F':
            strcat(rating, "*");
        default:
            ;
    }
    void (*next_addRating)(char*) = dlsym(RTLD_NEXT, "addRating");
    if (next_addRating) {
        next_addRating(rating);
    }
    else {
        printf("[%s] Fatal problem: %s", __FILE__, dlerror());
    }
}

// Interpose libRatings.B.dylib:medianRating.
EXPORT
char *medianRating(void) {
    char medianGrade[2] = { '\0' };
    char *(*next_medianRating)(void) = dlsym(RTLD_NEXT, "medianRating");
    if (next_medianRating) {
        strcpy(medianGrade, _ratingAsGrade(next_medianRating()));
    }
    else {
        printf("[%s] Fatal problem: %s", __FILE__, dlerror());
        exit(EXIT_FAILURE);
    }
    return strdup(medianGrade);
}

// Interpose libRatings.B.dylib:frequentRating.
EXPORT
char *frequentRating(void) {
    char frequentGrade[2] = { '\0' };
    char *(*next_frequentRating)(void) = dlsym(RTLD_NEXT, "frequentRating");
    if (next_frequentRating) {
        strcpy(frequentGrade, _ratingAsGrade(next_frequentRating()));
    }
    else {
        printf("[%s] Fatal problem: %s", __FILE__, dlerror());
        exit(EXIT_FAILURE);
    }
    return strdup(frequentGrade);
    
}

/* RatingsAsGraded Version History
 * 1. First version.
 */
